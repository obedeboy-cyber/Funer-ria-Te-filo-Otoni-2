import React, { useEffect, useState } from "react";

const logoSrc = "/logo.png";
const familyImageSrc = "/family.webp";

const plans = [
  {
    title: "Plano Individual",
    description: "Cobertura essencial para garantir amparo, organização e tranquilidade nos momentos mais delicados.",
  },
  {
    title: "Plano Familiar",
    description: "Proteção para toda a família com atendimento humanizado e benefícios pensados para quem você ama.",
  },
];

const testimonials = [
  {
    name: "Maria Silva",
    role: "Família atendida em 2023",
    text: "A Funerária Teófilo Otoni foi muito atenciosa e respeitosa em um momento tão difícil. Recomendo de coração para todos.",
    avatar: "MS",
  },
  {
    name: "João Santos",
    role: "Cliente há 5 anos",
    text: "Atendimento humanizado e profissional. A equipe nos ajudou com muita dedicação e carinho.",
    avatar: "JS",
  },
  {
    name: "Ana Costa",
    role: "Família atendida em 2024",
    text: "Excelente serviço! Desde o primeiro contato até o final, tudo foi organizado e feito com muita sensibilidade.",
    avatar: "AC",
  },
];

const cities = [
  "Teófilo Otoni",
  "Almenara",
  "Águas Formosas",
  "Ataléia",
  "Carlos Chagas",
  "Central de Minas",
  "Divisa Alegre",
  "Felisburgo",
  "Itabirinha",
  "Itambacuri",
  "Joaíma",
  "Ladainha",
  "Machacalis",
  "Malacacheta",
  "Mantena",
  "Mendes Pimentel",
  "Monte Formoso",
  "Nova Módica",
  "Pavão",
  "Pedra Azul",
  "Santa Efigênia",
  "Serra dos Aimorés",
  "Atendimento em todo o Brasil",
];

function SectionTitle({ eyebrow, title, text }) {
  return (
    <div className="max-w-2xl animate-fade-in">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700 dark:text-sky-400">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white md:text-4xl">{title}</h2>
      <p className="mt-4 text-base leading-7 text-slate-600 dark:text-slate-300 md:text-lg">{text}</p>
    </div>
  );
}

function IconBadge({ children }) {
  return (
    <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-sky-100 text-sky-700 dark:bg-sky-900 dark:text-sky-300 text-lg font-bold">
      {children}
    </span>
  );
}

function TestimonialCard({ testimonial, index }) {
  return (
    <div
      className="animate-fade-in-delay rounded-[1.5rem] border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="h-12 w-12 rounded-full bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center text-white font-bold text-sm">
          {testimonial.avatar}
        </div>
        <div>
          <h4 className="font-bold text-slate-900 dark:text-white">{testimonial.name}</h4>
          <p className="text-sm text-slate-600 dark:text-slate-400">{testimonial.role}</p>
        </div>
      </div>
      <p className="text-slate-600 dark:text-slate-300 leading-7">“{testimonial.text}”</p>
      <div className="flex gap-1 mt-4">
        {[...Array(5)].map((_, i) => (
          <span key={i} className="text-yellow-400">★</span>
        ))}
      </div>
    </div>
  );
}

export default function SiteFunerariaTeofiloOtoni() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const isDark = localStorage.getItem("darkMode") === "true";
    setDarkMode(isDark);
    if (isDark) document.documentElement.classList.add("dark");
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("darkMode", "true");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("darkMode", "false");
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 transition-colors duration-300">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInDelay {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in { animation: fadeIn 0.6s ease-out; }
        .animate-fade-in-delay { animation: fadeInDelay 0.6s ease-out forwards; opacity: 0; }
      `}</style>

      <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-slate-700/80 bg-white/95 dark:bg-slate-900/95 backdrop-blur transition-colors duration-300">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 md:px-6">
          <div className="flex items-center gap-3 md:gap-4">
            <img src={logoSrc} alt="Logo Funerária Teófilo Otoni" className="h-20 w-auto object-contain md:h-24" />
            <div className="hidden sm:block">
              <p className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white">Funerária Teófilo Otoni</p>
              <p className="text-xs uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">A mão amiga de todas as horas</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <nav className="hidden items-center gap-6 md:flex">
              <a href="#inicio" className="text-sm font-medium text-slate-600 dark:text-slate-300 transition hover:text-slate-900 dark:hover:text-white">Início</a>
              <a href="#planos" className="text-sm font-medium text-slate-600 dark:text-slate-300 transition hover:text-slate-900 dark:hover:text-white">Planos</a>
              <a href="#depoimentos" className="text-sm font-medium text-slate-600 dark:text-slate-300 transition hover:text-slate-900 dark:hover:text-white">Depoimentos</a>
              <a href="#cidades" className="text-sm font-medium text-slate-600 dark:text-slate-300 transition hover:text-slate-900 dark:hover:text-white">Cidades</a>
              <a href="#contato" className="text-sm font-medium text-slate-600 dark:text-slate-300 transition hover:text-slate-900 dark:hover:text-white">Contato</a>
            </nav>

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-yellow-400 transition hover:bg-slate-200 dark:hover:bg-slate-700"
              aria-label="Alternar modo escuro"
            >
              {darkMode ? "☀️" : "🌙"}
            </button>
          </div>
        </div>
      </header>

      <main>
        <section id="inicio" className="relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(14,165,233,0.12),_transparent_40%),linear-gradient(180deg,rgba(248,250,252,1),rgba(255,255,255,1))] dark:bg-[radial-gradient(circle_at_top,_rgba(14,165,233,0.08),_transparent_40%),linear-gradient(180deg,rgba(15,23,42,1),rgba(30,41,59,1))]" />
          <div className="relative mx-auto grid max-w-7xl gap-12 px-4 py-16 md:grid-cols-[0.9fr,1.1fr] md:px-6 md:py-24">
            <div className="flex flex-col justify-center">
              <div className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-sky-200 dark:border-sky-700 bg-sky-50 dark:bg-sky-900/30 px-4 py-2 text-sm font-medium text-sky-800 dark:text-sky-300 animate-fade-in">
                <span>●</span>
                Há 28 anos cuidando de quem você ama
              </div>

              <h1 className="text-4xl font-black tracking-tight text-slate-950 dark:text-white md:text-6xl animate-fade-in" style={{ animationDelay: "100ms" }}>
                Amparo, respeito e segurança para sua família.
              </h1>

              <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600 dark:text-slate-300 animate-fade-in" style={{ animationDelay: "200ms" }}>
                Atendimento humanizado, planos funerários acessíveis e suporte completo para trazer mais tranquilidade nos momentos em que você mais precisa.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row animate-fade-in" style={{ animationDelay: "300ms" }}>
                <a href="https://wa.me/553335211519" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-2xl bg-sky-700 dark:bg-sky-600 px-6 py-3 text-base font-semibold text-white transition hover:bg-sky-800 dark:hover:bg-sky-700 hover:-translate-y-0.5">
                  WhatsApp
                </a>
                <a href="tel:3335211519" aria-label="Ligar para 3521-1519" className="inline-flex items-center justify-center rounded-2xl border border-slate-300 dark:border-slate-600 px-6 py-3 text-base font-semibold text-slate-800 dark:text-slate-100 transition hover:bg-slate-50 dark:hover:bg-slate-800 hover:-translate-y-0.5">
                  Ligar agora
                </a>
              </div>

              <div className="mt-10 grid gap-4 sm:grid-cols-3">
                {[
                  { icon: "24", title: "Atendimento 24 horas", desc: "Disponíveis todos os dias para oferecer apoio rápido, respeitoso e eficiente." },
                  { icon: "♥", title: "Cuidado humanizado", desc: "Atendimento com empatia, acolhimento e seriedade em cada etapa." },
                  { icon: "✓", title: "Segurança familiar", desc: "Planos que ajudam a evitar imprevistos e trazem mais tranquilidade." },
                ].map((item, i) => (
                  <div key={i} className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-slate-800/90 p-4 shadow-sm transition hover:shadow-lg hover:-translate-y-1 animate-fade-in-delay" style={{ animationDelay: `${400 + i * 50}ms` }}>
                    <IconBadge>{item.icon}</IconBadge>
                    <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">{item.title}</p>
                    <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-300">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center animate-fade-in" style={{ animationDelay: "200ms" }}>
              <div className="w-full rounded-[2rem] border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-5 shadow-2xl shadow-sky-100 dark:shadow-sky-900/30">
                <div className="rounded-[1.5rem] bg-gradient-to-br from-sky-900 via-sky-700 to-blue-500 dark:from-sky-800 dark:via-sky-600 dark:to-blue-600 p-8 text-white">
                  <div className="flex justify-center">
                    <div className="rounded-2xl bg-white/95 px-6 py-4 shadow-lg">
                      <img src={logoSrc} alt="Logo Funerária Teófilo Otoni" className="h-auto w-full max-w-[280px] object-contain" />
                    </div>
                  </div>
                  <div className="mt-6 text-center">
                    <p className="text-sm font-extrabold uppercase tracking-[0.35em] text-white">Funerária</p>
                    <p className="mt-2 text-2xl font-black tracking-tight text-white md:text-3xl">Teófilo Otoni</p>
                  </div>
                  <h3 className="mt-3 text-center text-3xl font-black tracking-tight md:text-4xl">A mão amiga de todas as horas</h3>
                  <p className="mx-auto mt-4 max-w-md text-center text-base leading-7 text-sky-50/95">
                    Uma presença de confiança para apoiar famílias com dignidade, respeito e acolhimento em cada detalhe.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <div className="grid items-center gap-10 overflow-hidden rounded-[2rem] border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-xl md:grid-cols-[0.85fr,1.15fr] transition-colors duration-300">
            <div className="p-6 md:p-10 animate-fade-in">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-700 dark:text-sky-400">Cuidado com quem você ama</p>
              <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 dark:text-white md:text-4xl">
                Ter um plano é uma forma de proteger pais, filhos e toda a família.
              </h2>
              <p className="mt-5 text-base leading-8 text-slate-600 dark:text-slate-300 md:text-lg">
                Cuidar da família é demonstrar amor também no futuro. Um plano funerário ajuda a trazer mais tranquilidade, organização e apoio nos momentos em que seus entes queridos mais precisam.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a href="https://wa.me/553335211519" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-2xl bg-sky-700 dark:bg-sky-600 px-6 py-3 font-semibold text-white transition hover:bg-sky-800 dark:hover:bg-sky-700 hover:-translate-y-0.5">
                  Falar com nossa equipe
                </a>
                <a href="tel:3335211519" aria-label="Ligar para 3521-1519" className="inline-flex items-center justify-center rounded-2xl border border-slate-300 dark:border-slate-600 px-6 py-3 font-semibold text-slate-800 dark:text-slate-100 transition hover:bg-slate-50 dark:hover:bg-slate-700 hover:-translate-y-0.5">
                  3521-1519
                </a>
              </div>
            </div>
            <div className="bg-sky-50 dark:bg-sky-900/20 p-2 md:p-3">
              <img src={familyImageSrc} alt="Família feliz representando cuidado e proteção familiar" className="h-full min-h-[420px] w-full rounded-[1.5rem] object-cover md:min-h-[560px] transition-transform duration-300 hover:scale-105" />
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <SectionTitle eyebrow="Sobre nós" title="Cuidamos de cada família com respeito e sensibilidade" text="Nossa missão é oferecer apoio nos momentos mais delicados, com atendimento sério, acolhedor e organizado. Também trabalhamos com planos funerários para trazer proteção, previsibilidade e mais tranquilidade para o futuro." />

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[
              { title: "Atendimento acolhedor", desc: "Equipe preparada para atender com empatia, organização e responsabilidade em todos os momentos." },
              { title: "Planos acessíveis", desc: "Soluções pensadas para diferentes perfis, ajudando sua família a evitar imprevistos e despesas inesperadas." },
              { title: "Presença regional", desc: "Atuação em Teófilo Otoni e em diversas cidades da região, com suporte rápido e atendimento próximo." },
            ].map((item, i) => (
              <div key={i} className="rounded-[1.5rem] border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-6 shadow-sm transition hover:shadow-lg hover:-translate-y-1 animate-fade-in-delay" style={{ animationDelay: `${i * 100}ms` }}>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">{item.title}</h3>
                <p className="mt-3 leading-7 text-slate-600 dark:text-slate-300">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="planos" className="bg-slate-50 dark:bg-slate-800 transition-colors duration-300">
          <div className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
            <SectionTitle eyebrow="Planos funerários" title="Opções para proteger quem você ama" text="Escolha o plano que melhor se encaixa na sua realidade e tenha mais tranquilidade para cuidar do presente e do futuro da sua família." />

            <div className="mt-10 grid gap-6 md:grid-cols-2">
              {plans.map((plan, i) => (
                <div key={plan.title} className="rounded-[1.75rem] border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg animate-fade-in-delay" style={{ animationDelay: `${i * 100}ms` }}>
                  <div className="w-fit rounded-full bg-sky-100 dark:bg-sky-900/50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-sky-800 dark:text-sky-300">Proteção</div>
                  <h3 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">{plan.title}</h3>
                  <p className="mt-3 leading-7 text-slate-600 dark:text-slate-300">{plan.description}</p>
                  <a href="https://wa.me/553335211519" target="_blank" rel="noreferrer" className="mt-6 inline-flex rounded-2xl bg-slate-900 dark:bg-slate-700 px-5 py-3 font-semibold text-white transition hover:bg-slate-800 dark:hover:bg-slate-600 hover:-translate-y-0.5">
                    Solicitar informações
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="depoimentos" className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <SectionTitle eyebrow="Depoimentos" title="O que nossas famílias dizem sobre nós" text="Conheça as histórias de quem já confiou na Funerária Teófilo Otoni e experimentou nosso atendimento humanizado." />

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {testimonials.map((testimonial, i) => (
              <TestimonialCard key={i} testimonial={testimonial} index={i} />
            ))}
          </div>
        </section>

        <section id="cidades" className="bg-slate-50 dark:bg-slate-800 mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24 transition-colors duration-300">
          <SectionTitle eyebrow="Cidades atendidas" title="Uma rede de apoio preparada para atender com agilidade" text="Nossa estrutura está pronta para oferecer suporte em diferentes localidades, mantendo o compromisso com o respeito, a organização e o acolhimento." />

          <div className="mt-10 flex flex-wrap gap-3">
            {cities.map((city, i) => (
              <div key={city} className="rounded-full border border-sky-200 dark:border-sky-700 bg-sky-50 dark:bg-sky-900/30 px-4 py-3 text-sm font-medium text-sky-900 dark:text-sky-300 shadow-sm transition hover:-translate-y-0.5 animate-fade-in-delay" style={{ animationDelay: `${i * 30}ms` }}>
                {city}
              </div>
            ))}
          </div>
        </section>

        <section className="bg-gradient-to-br from-sky-900 via-slate-900 to-sky-800 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800 text-white transition-colors duration-300">
          <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-2 md:px-6 md:py-24">
            <div className="animate-fade-in">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-200 dark:text-sky-300">Atendimento imediato</p>
              <h2 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">Estamos prontos para ajudar sua família a qualquer momento.</h2>
              <p className="mt-5 max-w-xl text-base leading-8 text-slate-200 dark:text-slate-300 md:text-lg">
                Entre em contato agora para falar com nossa equipe, solicitar atendimento ou conhecer melhor os planos funerários da Funerária Teófilo Otoni.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a href="https://wa.me/553335211519" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-2xl bg-white px-6 py-3 font-semibold text-slate-900 transition hover:bg-slate-100 hover:-translate-y-0.5">
                  WhatsApp
                </a>
                <a href="tel:3335211519" aria-label="Ligar para 3521-1519" className="inline-flex items-center justify-center rounded-2xl border border-white/30 px-6 py-3 font-semibold text-white transition hover:bg-white/10 hover:-translate-y-0.5">
                  (33) 3521-1519
                </a>
              </div>
            </div>

            <div id="contato" className="rounded-[2rem] border border-white/10 bg-white/95 dark:bg-slate-800/95 p-6 text-slate-900 dark:text-white shadow-2xl md:p-8 animate-fade-in" style={{ animationDelay: "100ms" }}>
              <h3 className="text-2xl font-bold">Solicite atendimento</h3>
              <p className="mt-2 text-slate-600 dark:text-slate-300">Preencha os dados abaixo para receber contato da nossa equipe.</p>

              <div className="mt-6 space-y-4">
                <input placeholder="Seu nome" className="h-12 w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-4 text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 transition focus:outline-none focus:ring-2 focus:ring-sky-500" />
                <input placeholder="Seu telefone" className="h-12 w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-4 text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 transition focus:outline-none focus:ring-2 focus:ring-sky-500" />
                <input placeholder="Seu e-mail" className="h-12 w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-4 text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 transition focus:outline-none focus:ring-2 focus:ring-sky-500" />
                <textarea placeholder="Como podemos ajudar?" className="min-h-[120px] w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-4 py-3 text-slate-900 dark:text-white placeholder:text-slate-500 dark:placeholder:text-slate-400 transition focus:outline-none focus:ring-2 focus:ring-sky-500" />
                <button className="h-12 w-full rounded-xl bg-sky-700 dark:bg-sky-600 text-base font-semibold text-white transition hover:bg-sky-800 dark:hover:bg-sky-700 hover:-translate-y-0.5 active:translate-y-0">
                  Enviar solicitação
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 transition-colors duration-300">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-8 md:flex-row md:items-center md:justify-between md:px-6">
          <div className="flex items-center gap-4">
            <img src={logoSrc} alt="Logo Funerária Teófilo Otoni" className="h-20 w-auto object-contain md:h-24" />
            <div>
              <p className="text-lg font-bold text-slate-900 dark:text-white">Funerária Teófilo Otoni</p>
              <p className="text-sm text-slate-600 dark:text-slate-400">A mão amiga de todas as horas</p>
            </div>
          </div>
          <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400 md:text-right">
            <p>Teófilo Otoni (Matriz) • (33) 3521-1519</p>
            <p>Rua Dr Onofre Nº 601, Centro, Teófilo Otoni - MG</p>
            <p>CEP 39800-022</p>
            <p>Atendimento em todo o Brasil</p>
            <a href="https://www.instagram.com/funerariateo/?hl=pt" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-sky-700 dark:text-sky-400 transition hover:text-sky-900 dark:hover:text-sky-300">
              Instagram: @funerariateo
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
